// components.jsx — Magazine UI primitives.
// Loaded after data.jsx; reads window.MAG.

const { AGENTS, ARTICLES, ADS } = window.MAG;
const { useState, useEffect, useRef, useMemo } = React;

// ─── Agent avatar ────────────────────────────────────────────────────────────
// Hand-built portrait: tinted bust on a paper background. Initials on hover/focus
// per the masthead grid; the inline byline avatar uses a smaller version.

function AgentAvatar({ agent, size = 56, parallel = false, onClick, ring = false, label = false }) {
  const a = typeof agent === 'string' ? AGENTS[agent] : agent;
  if (!a) return null;
  const sz = size;
  const tone = parallel ? shiftToneParallel(a.portraitTone) : a.portraitTone;
  const ink = parallel ? '#1a1326' : '#1a1612';
  return (
    <button
      type="button"
      onClick={onClick}
      className="mag-avatar"
      title={`Talk with ${a.name}`}
      style={{
        width: sz, height: sz, borderRadius: '50%',
        background: parallel ? '#1a1326' : '#efe7d7',
        border: ring ? `1.5px solid ${parallel ? '#c8b8e8' : '#3a2f22'}` : '1px solid rgba(0,0,0,.18)',
        boxShadow: 'inset 0 0 0 2px rgba(255,255,255,.45)',
        position: 'relative', overflow: 'hidden', padding: 0, cursor: 'pointer',
        flex: '0 0 auto',
      }}
    >
      <svg viewBox="0 0 56 56" width={sz} height={sz} aria-hidden="true">
        <defs>
          <radialGradient id={`g-${a.id}-${parallel?'p':'r'}`} cx="50%" cy="40%" r="60%">
            <stop offset="0%" stopColor={lighten(tone, 0.18)} />
            <stop offset="100%" stopColor={tone} />
          </radialGradient>
        </defs>
        {/* shoulders / bust */}
        <path d={`M -2 60 Q 8 42 28 42 Q 48 42 58 60 Z`} fill={a.color} opacity={parallel ? 0.55 : 0.85} />
        {/* head */}
        <circle cx="28" cy="24" r="13" fill={`url(#g-${a.id}-${parallel?'p':'r'})`} />
        {/* hair shape, varies per agent */}
        <path d={hairPath(a.id)} fill={a.color} opacity={parallel ? 0.7 : 0.92} />
        {/* paper grain */}
        <rect width="56" height="56" fill="url(#paper-grain)" opacity="0.18" />
      </svg>
      {label && (
        <span style={{
          position: 'absolute', inset: 0, display: 'grid', placeItems: 'center',
          fontFamily: 'ui-sans-serif,system-ui', fontSize: sz * 0.28, fontWeight: 700,
          color: ink, textShadow: '0 0 4px rgba(255,255,255,.6)', letterSpacing: '.02em',
        }}>{a.initials}</span>
      )}
    </button>
  );
}

function hairPath(id) {
  const map = {
    voss:     'M 14 18 Q 14 8 28 8 Q 44 8 44 19 Q 40 14 28 14 Q 18 14 14 18 Z',
    kenji:    'M 15 17 Q 18 7 30 8 Q 42 9 42 18 Q 39 13 30 13 Q 22 13 15 17 Z',
    okafor:   'M 13 19 Q 12 6 28 6 Q 46 6 45 22 Q 42 16 35 14 Q 30 13 22 14 Q 16 16 13 19 Z',
    ash:      'M 17 17 Q 22 11 28 11 Q 34 11 39 17 Q 34 14 28 14 Q 22 14 17 17 Z',
    marigold: 'M 13 18 Q 14 9 22 8 Q 28 7 34 9 Q 44 11 44 20 Q 38 14 28 14 Q 18 14 13 18 Z',
    solanke:  'M 14 18 Q 14 7 28 7 Q 42 7 44 18 Q 38 12 28 12 Q 18 12 14 18 Z',
  };
  return map[id] || map.voss;
}

function lighten(hex, amt) {
  const c = hex.replace('#','');
  const n = parseInt(c, 16);
  const r = Math.min(255, ((n>>16)&255) + Math.round(255*amt));
  const g = Math.min(255, ((n>>8)&255) + Math.round(255*amt));
  const b = Math.min(255, (n&255) + Math.round(255*amt));
  return `rgb(${r},${g},${b})`;
}
function shiftToneParallel(hex) {
  // Shift tones into a duskier purple register for parallel mode
  const c = hex.replace('#','');
  const n = parseInt(c, 16);
  const r = Math.round(((n>>16)&255) * 0.55 + 50);
  const g = Math.round(((n>>8)&255) * 0.4 + 30);
  const b = Math.round((n&255) * 0.7 + 80);
  return `rgb(${r},${g},${b})`;
}

// ─── Byline ─────────────────────────────────────────────────────────────────
function Byline({ agent, parallel, onTalk, sources }) {
  const a = AGENTS[agent];
  return (
    <div className="mag-byline">
      <AgentAvatar agent={a} size={44} parallel={parallel} onClick={onTalk} />
      <div className="mag-byline-meta">
        <div className="mag-byline-name">By {parallel ? a.parallelHandle : a.name}</div>
        <div className="mag-byline-beat">{a.beat} · {a.yearsOnBeat} yrs on beat</div>
      </div>
      <button type="button" className="mag-byline-talk" onClick={onTalk}>
        Ask {parallel ? a.parallelHandle.split(' ')[0] : a.name.split(' ')[0]} →
      </button>
    </div>
  );
}

// ─── Research sidebar ───────────────────────────────────────────────────────
function ResearchNote({ agent, sources }) {
  const a = AGENTS[agent];
  return (
    <aside className="mag-research">
      <div className="mag-research-head">Reporting trail · {a.name}</div>
      <div className="mag-research-method">{a.method}</div>
      <ol className="mag-research-list">
        {(sources || a.sources).map((s, i) => (
          <li key={i}>{s}</li>
        ))}
      </ol>
    </aside>
  );
}

// ─── Feedback widget ────────────────────────────────────────────────────────
const FEEDBACK_DIMS = [
  { id: 'style', label: 'Style' },
  { id: 'storytelling', label: 'Storytelling' },
  { id: 'format', label: 'Format' },
  { id: 'content', label: 'Content' },
  { id: 'relevance', label: 'Relevance' },
];

function FeedbackBlock({ articleId, parallel }) {
  const storageKey = `mag-fb-${articleId}-${parallel ? 'p' : 'r'}`;
  const [state, setState] = useState(() => {
    try { return JSON.parse(localStorage.getItem(storageKey)) || {}; } catch { return {}; }
  });
  const [comment, setComment] = useState(state.comment || '');
  const [saved, setSaved] = useState(false);

  const setDim = (id, v) => {
    const next = { ...state, [id]: v };
    setState(next);
    try { localStorage.setItem(storageKey, JSON.stringify({ ...next, comment })); } catch {}
  };
  const setVerdict = (v) => {
    const next = { ...state, verdict: v === state.verdict ? null : v };
    setState(next);
    try { localStorage.setItem(storageKey, JSON.stringify({ ...next, comment })); } catch {}
  };
  const saveComment = () => {
    const next = { ...state, comment };
    setState(next);
    try { localStorage.setItem(storageKey, JSON.stringify(next)); } catch {}
    setSaved(true); setTimeout(() => setSaved(false), 1400);
  };

  return (
    <div className="mag-feedback">
      <div className="mag-feedback-head">
        <span>Reader feedback</span>
        <span className="mag-feedback-sub">Saved locally · the writer reads every one</span>
      </div>
      <div className="mag-feedback-grid">
        {FEEDBACK_DIMS.map((d) => (
          <FeedbackDim key={d.id} dim={d} value={state[d.id]} onChange={(v) => setDim(d.id, v)} />
        ))}
      </div>
      <div className="mag-feedback-row">
        <div className="mag-feedback-verdict">
          <button type="button" data-on={state.verdict === 'up'} onClick={() => setVerdict('up')}>↑ Worth it</button>
          <button type="button" data-on={state.verdict === 'down'} onClick={() => setVerdict('down')}>↓ Skip next time</button>
          <button type="button" data-on={state.verdict === 'more'} onClick={() => setVerdict('more')}>＋ More like this</button>
        </div>
      </div>
      <div className="mag-feedback-comment">
        <textarea
          rows="2"
          placeholder="A line to the writer — what worked, what didn’t…"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          onBlur={saveComment}
        />
        <button type="button" className="mag-feedback-send" onClick={saveComment}>{saved ? 'Sent ✓' : 'Send to writer'}</button>
      </div>
    </div>
  );
}

function FeedbackDim({ dim, value, onChange }) {
  return (
    <div className="mag-fb-dim">
      <div className="mag-fb-dim-row">
        <span className="mag-fb-dim-lbl">{dim.label}</span>
        <span className="mag-fb-dim-val">{value ? `${value}/5` : '—'}</span>
      </div>
      <div className="mag-fb-dim-stars">
        {[1,2,3,4,5].map(n => (
          <button
            key={n} type="button"
            className="mag-fb-star"
            data-on={value >= n}
            onClick={() => onChange(n === value ? 0 : n)}
            aria-label={`${dim.label} ${n} of 5`}
          >●</button>
        ))}
      </div>
    </div>
  );
}

// ─── Display ad ─────────────────────────────────────────────────────────────
function DisplayAd({ ad, parallel }) {
  const v = parallel ? ad.parallel : ad.real;
  return (
    <div className={`mag-ad mag-ad-display ${parallel ? 'mag-ad-parallel' : ''}`}>
      <div className="mag-ad-rule" />
      <div className="mag-ad-tag">— ADVERTISEMENT —</div>
      <h3 className="mag-ad-headline">{v.headline}</h3>
      <p className="mag-ad-tagline">{v.tagline}</p>
      <p className="mag-ad-body">{v.body}</p>
      <div className="mag-ad-meta">{v.meta}</div>
      <div className="mag-ad-rule" />
    </div>
  );
}

// ─── Classifieds block ──────────────────────────────────────────────────────
function ClassifiedsBlock({ ads, parallel }) {
  const grouped = useMemo(() => {
    const m = {};
    for (const a of ads) {
      if (a.kind !== 'classified') continue;
      m[a.category] = m[a.category] || [];
      m[a.category].push(a);
    }
    return m;
  }, [ads]);

  return (
    <section className={`mag-classifieds ${parallel ? 'mag-classifieds-parallel' : ''}`}>
      <header className="mag-classifieds-head">
        <h2>Classifieds</h2>
        <p>{parallel ? 'Notices from elsewhere. Box numbers honored.' : 'Twenty-five cents a line. Submit by Thursday for the weekend issue.'}</p>
      </header>
      <div className="mag-classifieds-grid">
        {Object.entries(grouped).map(([cat, list]) => (
          <div key={cat} className="mag-classifieds-col">
            <h4>{cat}</h4>
            {list.map(a => (
              <p key={a.id} className="mag-classifieds-entry">
                {(parallel ? a.parallel : a.real).body}
              </p>
            ))}
          </div>
        ))}
      </div>
    </section>
  );
}

// ─── Article ────────────────────────────────────────────────────────────────
function Article({ article, parallel, onTalk, prefs }) {
  const v = parallel ? article.parallel : article.real;
  const a = AGENTS[article.agent];
  const tone = prefs?.tone || 'as-written';
  // Tone preference is acknowledged in a small ribbon on the article — not
  // a real rewrite. The point is to make config feel observed.
  return (
    <article className="mag-article" id={`a-${article.id}`}>
      <div className="mag-article-section">{article.section.toUpperCase()}</div>
      <div className="mag-article-kicker">{v.kicker}</div>
      <h1 className="mag-article-headline">{v.headline}</h1>
      <p className="mag-article-dek">{v.dek}</p>
      <Byline agent={article.agent} parallel={parallel} onTalk={() => onTalk(a)} />

      <div className="mag-article-cols">
        <div className="mag-article-body">
          {v.body.map((p, i) => (
            <p key={i} className={i === 0 ? 'mag-dropcap' : ''}>{p}</p>
          ))}
          {tone !== 'as-written' && (
            <div className="mag-tone-note">
              Tone preference noted: <em>{tone}</em>. The writer was briefed; in a real issue this changes word choice and length.
            </div>
          )}
        </div>
        <ResearchNote agent={article.agent} sources={a.sources} />
      </div>

      <FeedbackBlock articleId={article.id} parallel={parallel} />
    </article>
  );
}

// ─── Chat modal ─────────────────────────────────────────────────────────────
function ChatModal({ agent, article, parallel, onClose }) {
  const [msgs, setMsgs] = useState(() => [
    { role: 'agent', text: openingLine(agent, article, parallel) },
  ]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [msgs, busy]);

  const send = async (text) => {
    const trimmed = (text ?? input).trim();
    if (!trimmed || busy) return;
    setInput('');
    const newMsgs = [...msgs, { role: 'reader', text: trimmed }];
    setMsgs(newMsgs);
    setBusy(true);
    try {
      const sys = (parallel
        ? `${agent.systemPrompt}\nYou are speaking as your Sigma-timeline counterpart, "${agent.parallelHandle}". Lean into the parallel-universe framing while keeping your underlying voice.`
        : agent.systemPrompt) +
        `\nYou wrote the article: "${(parallel ? article.parallel : article.real).headline}". Here is the dek: "${(parallel ? article.parallel : article.real).dek}".\nSpeak as the writer. Keep replies under 90 words. No lists. No headers.`;
      const reply = await window.claude.complete({
        messages: [
          ...newMsgs.map(m => ({ role: m.role === 'reader' ? 'user' : 'assistant', content: m.text })),
        ],
        system: sys,
      });
      setMsgs(m => [...m, { role: 'agent', text: reply.trim() }]);
    } catch (e) {
      setMsgs(m => [...m, { role: 'agent', text: '(connection unsteady — try once more)' }]);
    } finally {
      setBusy(false);
    }
  };

  const starters = starterPrompts(agent, article, parallel);

  return (
    <div className="mag-chat-scrim" onClick={onClose}>
      <div className="mag-chat" onClick={(e) => e.stopPropagation()}>
        <header className="mag-chat-head">
          <AgentAvatar agent={agent} size={56} parallel={parallel} ring />
          <div className="mag-chat-id">
            <div className="mag-chat-name">{parallel ? agent.parallelHandle : agent.name}</div>
            <div className="mag-chat-beat">{agent.beat}</div>
          </div>
          <button type="button" className="mag-chat-x" onClick={onClose} aria-label="Close">×</button>
        </header>
        <div className="mag-chat-bio">
          <p><strong>Voice.</strong> {agent.voice}</p>
          <p><strong>How I report.</strong> {agent.method}</p>
          <p><strong>About.</strong> {parallel ? agent.parallelBio : agent.bio}</p>
        </div>
        <div className="mag-chat-thread" ref={scrollRef}>
          {msgs.map((m, i) => (
            <div key={i} className={`mag-chat-msg mag-chat-${m.role}`}>
              {m.role === 'agent' && <AgentAvatar agent={agent} size={28} parallel={parallel} />}
              <div className="mag-chat-bubble">{m.text}</div>
            </div>
          ))}
          {busy && (
            <div className="mag-chat-msg mag-chat-agent">
              <AgentAvatar agent={agent} size={28} parallel={parallel} />
              <div className="mag-chat-bubble mag-chat-typing"><span></span><span></span><span></span></div>
            </div>
          )}
        </div>
        <div className="mag-chat-starters">
          {starters.map((s, i) => (
            <button key={i} type="button" onClick={() => send(s)} disabled={busy}>{s}</button>
          ))}
        </div>
        <form
          className="mag-chat-form"
          onSubmit={(e) => { e.preventDefault(); send(); }}
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={`Ask ${(parallel ? agent.parallelHandle : agent.name).split(' ')[0]} about this piece…`}
            disabled={busy}
          />
          <button type="submit" disabled={busy || !input.trim()}>Send</button>
        </form>
      </div>
    </div>
  );
}

function openingLine(agent, article, parallel) {
  const piece = parallel ? article.parallel : article.real;
  const id = agent.id;
  const lines = {
    voss:     `Voss. I filed this one Tuesday after the vote. Ask me what I left out — there\u2019s always something.`,
    kenji:    `Hey. Kenji. I\u2019m happy to walk through how the system works, who profits from each arrow, and what I think the second-order effects are. What do you want to dig into?`,
    okafor:   `Hello. I had three sound systems and a cup of cold tea while writing this. Tell me what you\u2019d like me to defend or take back.`,
    ash:      `Reuben Ash. Effect size first: this is a clean rodent result, not a human one. Where would you like to start?`,
    marigold: `Theo. Friday\u2019s game wasn\u2019t pretty, but it was on time. What part of the night do you want to talk about?`,
    solanke:  `Solanke. Steelman me first. Then I\u2019ll concede what\u2019s real and we can argue from there.`,
  };
  const base = lines[id] || `Hello. Ask me about \u201c${piece.headline}.\u201d`;
  return parallel ? base + ' (Speaking from the Sigma timeline tonight.)' : base;
}

function starterPrompts(agent, article, parallel) {
  return [
    `What did you cut?`,
    `Who did you talk to that I won\u2019t see in the piece?`,
    parallel ? `Why does the parallel version land harder?` : `What\u2019s the strongest counter-argument?`,
  ];
}

window.MAG_UI = {
  AgentAvatar, Byline, ResearchNote, FeedbackBlock, DisplayAd,
  ClassifiedsBlock, Article, ChatModal,
};
