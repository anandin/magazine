// app.jsx — Magazine main app: cover, masthead, mode toggle, config, layout.
// Loaded last; uses window.MAG (data) and window.MAG_UI (components).

const { AGENTS, ARTICLES, ADS } = window.MAG;
const {
  AgentAvatar, Byline, ResearchNote, FeedbackBlock, DisplayAd,
  ClassifiedsBlock, Article, ChatModal,
} = window.MAG_UI;
const { useState, useEffect, useMemo, useRef } = React;

// ── Preferences ──────────────────────────────────────────────────────────────
const PREF_STORAGE = 'mag-prefs-v1';
const DEFAULT_PREFS = {
  // Onboarding gate
  onboarded: false,
  // Identity
  name: '',
  city: 'Cedar Hollow',
  // Topics — multi-select tags
  topics: ['Politics & City Hall', 'Technology & AI Policy', 'Science & Health', 'Culture'],
  // Tone
  tone: 'as-written', // as-written | dry | witty | deep-dive | snappy
  // Length
  length: 'medium',   // short | medium | long
  // Format
  visualWeight: 'balanced', // text-heavy | balanced | image-heavy
  // Reading level
  readingLevel: 'engaged-adult', // skim | engaged-adult | wonk
  // Locality
  localPriority: 0.6, // 0..1
  // Banned topics
  banned: [],
  // Expectations — freeform
  expectations: '',
};

function loadPrefs() {
  try {
    const raw = localStorage.getItem(PREF_STORAGE);
    if (!raw) return DEFAULT_PREFS;
    return { ...DEFAULT_PREFS, ...JSON.parse(raw) };
  } catch { return DEFAULT_PREFS; }
}
function savePrefs(p) {
  try { localStorage.setItem(PREF_STORAGE, JSON.stringify(p)); } catch {}
}

// ── Layout: interleave articles + display ads ────────────────────────────────
function buildSpread(articles, ads) {
  // Pattern: article, article, display-ad, article, display-ad, article, article, display-ad
  const displays = ads.filter(a => a.kind === 'display');
  const out = [];
  let di = 0;
  articles.forEach((art, i) => {
    out.push({ kind: 'article', data: art });
    if ((i + 1) % 2 === 0 && di < displays.length) {
      out.push({ kind: 'ad', data: displays[di++] });
    }
  });
  while (di < displays.length) out.push({ kind: 'ad', data: displays[di++] });
  return out;
}

// ── Cover ────────────────────────────────────────────────────────────────────
function Cover({ parallel, prefs, issueNo, onScrollIn }) {
  const masthead = parallel ? 'The Cedar Hollow Sentinel' : 'The Cedar Hollow Sentinel';
  const sub = parallel ? 'σ — sigma edition' : '— a weekly';
  const date = 'Friday · May 8, 2026';
  // Build the cover lead — pull the first article for the headline poster.
  const lead = ARTICLES[0];
  const leadV = parallel ? lead.parallel : lead.real;
  return (
    <header className={`mag-cover ${parallel ? 'mag-cover-parallel' : ''}`}>
      <div className="mag-cover-rule mag-cover-rule-top" />
      <div className="mag-cover-meta">
        <span>Vol. LIV · No. {issueNo}</span>
        <span>{date}</span>
        <span>{prefs.name ? `For ${prefs.name}` : 'For the discerning reader'} · {prefs.city}</span>
      </div>
      <div className="mag-cover-rule" />
      <h1 className="mag-masthead">
        {masthead}
        {parallel && <span className="mag-masthead-sigma"> Σ</span>}
      </h1>
      <div className="mag-cover-tagline">
        {parallel
          ? '“The news as it might have been, told by the same writers, in a different draft.”'
          : '“Reported on foot. Edited on paper. Printed for the people who actually read.”'}
      </div>
      <div className="mag-cover-rule" />

      <div className="mag-cover-lead">
        <div className="mag-cover-lead-section">
          <div className="mag-cover-lead-kicker">{leadV.kicker}</div>
          <h2 className="mag-cover-lead-headline">{leadV.headline}</h2>
          <p className="mag-cover-lead-dek">{leadV.dek}</p>
          <button className="mag-cover-lead-jump" onClick={onScrollIn}>Begin reading ↓</button>
        </div>
        <div className="mag-cover-lead-art">
          <CoverArt parallel={parallel} />
        </div>
      </div>

      <div className="mag-cover-rule" />
      <div className="mag-cover-index">
        <span><b>Inside:</b></span>
        {ARTICLES.map((a, i) => (
          <span key={a.id}>
            <a href={`#a-${a.id}`}>{(parallel ? a.parallel : a.real).headline.split(';')[0].split(',')[0]}</a>
            {i < ARTICLES.length - 1 && <span className="mag-cover-index-dot"> · </span>}
          </span>
        ))}
      </div>
      <div className="mag-cover-rule mag-cover-rule-bot" />
    </header>
  );
}

// Hand-drawn cover art: a duotone newspaper-style illustration that swaps for parallel
function CoverArt({ parallel }) {
  if (parallel) {
    return (
      <svg viewBox="0 0 320 320" className="mag-cover-art mag-cover-art-parallel">
        <defs>
          <radialGradient id="par-sky" cx="50%" cy="40%" r="70%">
            <stop offset="0%" stopColor="#3b1f5e" />
            <stop offset="60%" stopColor="#1a0f30" />
            <stop offset="100%" stopColor="#0a0518" />
          </radialGradient>
          <pattern id="par-stipple" width="3" height="3" patternUnits="userSpaceOnUse">
            <circle cx="1.5" cy="1.5" r="0.5" fill="#c8b8e8" opacity="0.5" />
          </pattern>
        </defs>
        <rect width="320" height="320" fill="url(#par-sky)" />
        <rect width="320" height="320" fill="url(#par-stipple)" />
        {/* second sun / moon */}
        <circle cx="220" cy="100" r="44" fill="#e8d8ff" opacity="0.85" />
        <circle cx="220" cy="100" r="44" fill="none" stroke="#c8b8e8" strokeWidth="1" strokeDasharray="2 4" />
        {/* mirror skyline reflected */}
        <path d="M 0 220 L 30 200 L 30 220 L 70 190 L 70 220 L 110 175 L 110 220 L 160 200 L 160 220 L 220 180 L 220 220 L 260 195 L 260 220 L 320 205 L 320 320 L 0 320 Z" fill="#0a0518" opacity="0.95" />
        <path d="M 0 220 L 30 240 L 30 220 L 70 250 L 70 220 L 110 265 L 110 220 L 160 240 L 160 220 L 220 260 L 220 220 L 260 245 L 260 220 L 320 235 L 320 220 Z" fill="#5a3d8a" opacity="0.4" />
        {/* tiny windows */}
        {Array.from({ length: 14 }).map((_, i) => (
          <rect key={i} x={20 + i * 22} y={210 - (i % 4) * 8} width="2" height="2" fill="#fff7c8" opacity="0.85" />
        ))}
        {/* slogan */}
        <text x="20" y="40" fill="#c8b8e8" fontSize="11" letterSpacing="3">SIGMA EDITION</text>
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 320 320" className="mag-cover-art">
      <defs>
        <pattern id="real-stipple" width="3" height="3" patternUnits="userSpaceOnUse">
          <circle cx="1.5" cy="1.5" r="0.5" fill="#1a1612" opacity="0.7" />
        </pattern>
        <linearGradient id="real-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#efe7d7" />
          <stop offset="100%" stopColor="#dccdb0" />
        </linearGradient>
      </defs>
      <rect width="320" height="320" fill="url(#real-sky)" />
      {/* sun */}
      <circle cx="240" cy="90" r="36" fill="none" stroke="#1a1612" strokeWidth="1.5" />
      <g stroke="#1a1612" strokeWidth="1.2" opacity="0.6">
        {Array.from({ length: 18 }).map((_, i) => {
          const a = (i / 18) * Math.PI * 2;
          return <line key={i} x1={240 + Math.cos(a) * 40} y1={90 + Math.sin(a) * 40} x2={240 + Math.cos(a) * (50 + (i%2)*6)} y2={90 + Math.sin(a) * (50 + (i%2)*6)} />;
        })}
      </g>
      {/* skyline of the city */}
      <path d="M 0 220 L 30 200 L 30 220 L 70 190 L 70 220 L 110 175 L 110 220 L 160 200 L 160 220 L 220 180 L 220 220 L 260 195 L 260 220 L 320 205 L 320 320 L 0 320 Z" fill="#1a1612" />
      <rect x="0" y="220" width="320" height="100" fill="url(#real-stipple)" />
      {/* a tiny figure */}
      <g transform="translate(56 250)" stroke="#efe7d7" strokeWidth="1.5" fill="none">
        <circle cx="0" cy="-10" r="3" />
        <line x1="0" y1="-7" x2="0" y2="6" />
        <line x1="-5" y1="2" x2="5" y2="2" />
        <line x1="-3" y1="14" x2="0" y2="6" />
        <line x1="3" y1="14" x2="0" y2="6" />
      </g>
      {/* a bicycle */}
      <g transform="translate(180 270)" stroke="#efe7d7" strokeWidth="1.5" fill="none">
        <circle cx="-10" cy="0" r="8" />
        <circle cx="14" cy="0" r="8" />
        <path d="M -10 0 L 0 -10 L 14 0" />
        <path d="M 0 -10 L 4 -16" />
      </g>
    </svg>
  );
}

// ── Top utility bar ──────────────────────────────────────────────────────────
function UtilityBar({ parallel, onToggleMode, onOpenPrefs, onOpenMasthead, prefs }) {
  return (
    <div className={`mag-util ${parallel ? 'mag-util-parallel' : ''}`}>
      <div className="mag-util-inner">
        <div className="mag-util-left">
          <button type="button" onClick={onOpenMasthead}>Masthead</button>
          <button type="button" onClick={onOpenPrefs}>My Edition</button>
        </div>
        <div className="mag-util-mode">
          <button
            type="button"
            className={`mag-mode-toggle ${parallel ? 'is-parallel' : ''}`}
            onClick={onToggleMode}
            aria-label="Toggle reality mode"
          >
            <span className="mag-mode-track">
              <span className={`mag-mode-pill mag-mode-pill-real ${!parallel ? 'is-active' : ''}`}>REAL</span>
              <span className={`mag-mode-pill mag-mode-pill-par ${parallel ? 'is-active' : ''}`}>PARALLEL Σ</span>
              <span className="mag-mode-thumb" />
            </span>
          </button>
        </div>
        <div className="mag-util-right">
          <span className="mag-util-stamp">Issue 218 · May 8, 2026</span>
        </div>
      </div>
    </div>
  );
}

// ── Preferences drawer ──────────────────────────────────────────────────────
const ALL_TOPICS = [
  'Politics & City Hall', 'Technology & AI Policy', 'Science & Health',
  'Culture', 'Sports', 'Opinion', 'Business', 'Climate', 'Local',
];
const TONES = [
  { id: 'as-written', label: 'As written', sub: 'Trust the writer' },
  { id: 'dry',         label: 'Dry',        sub: 'Just the facts' },
  { id: 'witty',       label: 'Witty',      sub: 'Voice forward' },
  { id: 'deep-dive',   label: 'Deep dive',  sub: 'Show the work' },
  { id: 'snappy',      label: 'Snappy',     sub: 'Get me moving' },
];

function PrefsDrawer({ open, prefs, setPrefs, onClose, firstRun = false }) {
  const [draft, setDraft] = useState(prefs);
  useEffect(() => { if (open) setDraft(prefs); }, [open]);

  if (!open) return null;
  const toggleTopic = (t) => {
    setDraft(d => ({
      ...d,
      topics: d.topics.includes(t) ? d.topics.filter(x => x !== t) : [...d.topics, t],
    }));
  };
  const toggleBanned = (t) => {
    setDraft(d => ({
      ...d,
      banned: d.banned.includes(t) ? d.banned.filter(x => x !== t) : [...d.banned, t],
    }));
  };

  const save = () => {
    setPrefs({ ...draft, onboarded: true });
    onClose();
  };

  return (
    <div className="mag-drawer-scrim" onClick={firstRun ? undefined : onClose}>
      <div className="mag-drawer" onClick={(e) => e.stopPropagation()}>
        <header className="mag-drawer-head">
          <div>
            <h2>{firstRun ? 'Welcome — let’s set your edition' : 'My Edition'}</h2>
            <p>Tell the writers what you want. They will read this and you can change it any week.</p>
          </div>
          {!firstRun && <button type="button" className="mag-chat-x" onClick={onClose}>×</button>}
        </header>

        <section className="mag-pref-sect">
          <label className="mag-pref-label">Your name (optional)</label>
          <input
            type="text"
            className="mag-pref-input"
            value={draft.name}
            onChange={(e) => setDraft({ ...draft, name: e.target.value })}
            placeholder="So we can address you on the cover"
          />
        </section>

        <section className="mag-pref-sect">
          <label className="mag-pref-label">City for the local section</label>
          <input
            type="text"
            className="mag-pref-input"
            value={draft.city}
            onChange={(e) => setDraft({ ...draft, city: e.target.value })}
            placeholder="Cedar Hollow"
          />
        </section>

        <section className="mag-pref-sect">
          <label className="mag-pref-label">What you’d like covered</label>
          <div className="mag-pref-tags">
            {ALL_TOPICS.map(t => (
              <button
                key={t} type="button"
                className="mag-pref-tag"
                data-on={draft.topics.includes(t)}
                onClick={() => toggleTopic(t)}
              >{t}</button>
            ))}
          </div>
        </section>

        <section className="mag-pref-sect">
          <label className="mag-pref-label">Tone of writing</label>
          <div className="mag-pref-tones">
            {TONES.map(t => (
              <button
                key={t.id} type="button"
                className="mag-pref-tone"
                data-on={draft.tone === t.id}
                onClick={() => setDraft({ ...draft, tone: t.id })}
              >
                <b>{t.label}</b>
                <span>{t.sub}</span>
              </button>
            ))}
          </div>
        </section>

        <section className="mag-pref-sect mag-pref-row2">
          <div>
            <label className="mag-pref-label">Length preference</label>
            <div className="mag-pref-seg">
              {['short','medium','long'].map(v => (
                <button key={v} type="button" data-on={draft.length === v}
                  onClick={() => setDraft({ ...draft, length: v })}>{v}</button>
              ))}
            </div>
          </div>
          <div>
            <label className="mag-pref-label">Visual weight</label>
            <div className="mag-pref-seg">
              {['text-heavy','balanced','image-heavy'].map(v => (
                <button key={v} type="button" data-on={draft.visualWeight === v}
                  onClick={() => setDraft({ ...draft, visualWeight: v })}>{v}</button>
              ))}
            </div>
          </div>
          <div>
            <label className="mag-pref-label">Reading level</label>
            <div className="mag-pref-seg">
              {[
                ['skim','skim'],
                ['engaged-adult','engaged'],
                ['wonk','wonk'],
              ].map(([id,lbl]) => (
                <button key={id} type="button" data-on={draft.readingLevel === id}
                  onClick={() => setDraft({ ...draft, readingLevel: id })}>{lbl}</button>
              ))}
            </div>
          </div>
        </section>

        <section className="mag-pref-sect">
          <label className="mag-pref-label">
            Local priority <span className="mag-pref-hint">how much of the issue should be your city</span>
          </label>
          <div className="mag-pref-slider">
            <input
              type="range" min="0" max="1" step="0.05"
              value={draft.localPriority}
              onChange={(e) => setDraft({ ...draft, localPriority: parseFloat(e.target.value) })}
            />
            <span>{Math.round(draft.localPriority * 100)}% local</span>
          </div>
        </section>

        <section className="mag-pref-sect">
          <label className="mag-pref-label">Topics to keep out</label>
          <div className="mag-pref-tags">
            {ALL_TOPICS.map(t => (
              <button
                key={t} type="button"
                className="mag-pref-tag mag-pref-tag-ban"
                data-on={draft.banned.includes(t)}
                onClick={() => toggleBanned(t)}
              >{t}</button>
            ))}
          </div>
        </section>

        <section className="mag-pref-sect">
          <label className="mag-pref-label">What you expect from this magazine</label>
          <textarea
            className="mag-pref-textarea"
            rows="3"
            value={draft.expectations}
            onChange={(e) => setDraft({ ...draft, expectations: e.target.value })}
            placeholder="“I want one piece that surprises me each week. Skip the celebrity stuff. I want to learn one thing I can use.”"
          />
        </section>

        <footer className="mag-drawer-foot">
          <span className="mag-drawer-foot-note">Saved to this device. The writers will see your settings on the next issue.</span>
          <button type="button" className="mag-drawer-save" onClick={save}>
            {firstRun ? 'Open my issue →' : 'Save preferences'}
          </button>
        </footer>
      </div>
    </div>
  );
}

// ── Masthead modal — lists writers, click to open chat ──────────────────────
function MastheadModal({ open, parallel, onClose, onOpenAgent }) {
  if (!open) return null;
  return (
    <div className="mag-drawer-scrim" onClick={onClose}>
      <div className="mag-masthead-modal" onClick={(e) => e.stopPropagation()}>
        <header className="mag-drawer-head">
          <div>
            <h2>The Masthead</h2>
            <p>Six writers. Each piece in the issue is theirs. You can review them, and you can talk with them about what they wrote.</p>
          </div>
          <button type="button" className="mag-chat-x" onClick={onClose}>×</button>
        </header>
        <div className="mag-masthead-grid">
          {Object.values(AGENTS).map((a) => (
            <AgentCard key={a.id} agent={a} parallel={parallel} onOpen={() => onOpenAgent(a)} />
          ))}
        </div>
      </div>
    </div>
  );
}

function AgentCard({ agent, parallel, onOpen }) {
  // Local rating for the writer (separate from per-article feedback)
  const k = `mag-writer-${agent.id}`;
  const [score, setScore] = useState(() => {
    try { return Number(localStorage.getItem(k)) || 0; } catch { return 0; }
  });
  const setS = (n) => {
    const v = n === score ? 0 : n;
    setScore(v);
    try { localStorage.setItem(k, String(v)); } catch {}
  };
  return (
    <div className="mag-masthead-card">
      <div className="mag-masthead-card-top">
        <AgentAvatar agent={agent} size={72} parallel={parallel} onClick={onOpen} ring />
        <div>
          <div className="mag-masthead-card-name">{parallel ? agent.parallelHandle : agent.name}</div>
          <div className="mag-masthead-card-beat">{agent.beat}</div>
          <div className="mag-masthead-card-years">{agent.yearsOnBeat} years on beat</div>
        </div>
      </div>
      <p className="mag-masthead-card-bio">{parallel ? agent.parallelBio : agent.bio}</p>
      <p className="mag-masthead-card-voice"><b>Voice.</b> {agent.voice}</p>
      <div className="mag-masthead-card-foot">
        <div className="mag-masthead-card-rate">
          <span>Rate this writer</span>
          <div className="mag-fb-dim-stars">
            {[1,2,3,4,5].map(n => (
              <button key={n} type="button" className="mag-fb-star" data-on={score >= n} onClick={() => setS(n)}>●</button>
            ))}
          </div>
        </div>
        <button type="button" className="mag-masthead-card-talk" onClick={onOpen}>Talk with {agent.name.split(' ')[0]} →</button>
      </div>
    </div>
  );
}

// ── App ──────────────────────────────────────────────────────────────────────
function App() {
  const [parallel, setParallel] = useState(false);
  const [prefs, setPrefsState] = useState(() => loadPrefs());
  const [drawerOpen, setDrawerOpen] = useState(!loadPrefs().onboarded);
  const [mastheadOpen, setMastheadOpen] = useState(false);
  const [chat, setChat] = useState(null); // { agent, article }
  const [phase, setPhase] = useState(null); // for parallel transition
  const issueRef = useRef(null);

  const setPrefs = (p) => { setPrefsState(p); savePrefs(p); };

  const spread = useMemo(() => buildSpread(ARTICLES, ADS), []);

  const openChatForArticle = (agent, article) => setChat({ agent, article });
  const openChatForAgent = (agent) => setChat({ agent, article: ARTICLES.find(a => a.agent === agent.id) || ARTICLES[0] });

  const toggleMode = () => {
    setPhase('flip');
    setTimeout(() => {
      setParallel(p => !p);
      setPhase('settle');
      setTimeout(() => setPhase(null), 700);
    }, 280);
  };

  const scrollToFirst = () => {
    document.getElementById('issue-start')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className={`mag-root ${parallel ? 'mag-parallel' : 'mag-real'} ${phase ? `mag-phase-${phase}` : ''}`}>
      {/* SVG defs (paper grain) reused across avatars */}
      <svg width="0" height="0" style={{ position: 'absolute' }}>
        <defs>
          <filter id="paper-noise">
            <feTurbulence baseFrequency="0.9" numOctaves="2" />
            <feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0.5 0" />
          </filter>
          <pattern id="paper-grain" width="80" height="80" patternUnits="userSpaceOnUse">
            <rect width="80" height="80" filter="url(#paper-noise)" />
          </pattern>
        </defs>
      </svg>

      <UtilityBar
        parallel={parallel}
        prefs={prefs}
        onToggleMode={toggleMode}
        onOpenPrefs={() => setDrawerOpen(true)}
        onOpenMasthead={() => setMastheadOpen(true)}
      />

      <div className="mag-paper" ref={issueRef}>
        <Cover parallel={parallel} prefs={prefs} issueNo={218} onScrollIn={scrollToFirst} />

        <div id="issue-start" />

        <main className="mag-issue">
          {spread.map((slot, i) => {
            if (slot.kind === 'article') {
              const art = slot.data;
              return (
                <Article
                  key={art.id}
                  article={art}
                  parallel={parallel}
                  prefs={prefs}
                  onTalk={(agent) => openChatForArticle(agent, art)}
                />
              );
            }
            return <DisplayAd key={`ad-${i}`} ad={slot.data} parallel={parallel} />;
          })}
          <ClassifiedsBlock ads={ADS} parallel={parallel} />

          <Colophon parallel={parallel} />
        </main>
      </div>

      {/* Mode-flip overlay */}
      {phase === 'flip' && <div className="mag-flip-curtain" />}

      <PrefsDrawer
        open={drawerOpen}
        prefs={prefs}
        setPrefs={setPrefs}
        firstRun={!prefs.onboarded}
        onClose={() => setDrawerOpen(false)}
      />

      <MastheadModal
        open={mastheadOpen}
        parallel={parallel}
        onClose={() => setMastheadOpen(false)}
        onOpenAgent={(a) => { setMastheadOpen(false); openChatForAgent(a); }}
      />

      {chat && (
        <ChatModal
          agent={chat.agent}
          article={chat.article}
          parallel={parallel}
          onClose={() => setChat(null)}
        />
      )}

      <MagTweaks
        parallel={parallel}
        onToggleParallel={toggleMode}
        onOpenPrefs={() => setDrawerOpen(true)}
        onOpenMasthead={() => setMastheadOpen(true)}
        onResetFeedback={() => {
          const keys = [];
          for (let i = 0; i < localStorage.length; i++) {
            const k = localStorage.key(i);
            if (k && (k.startsWith('mag-fb-') || k.startsWith('mag-writer-'))) keys.push(k);
          }
          keys.forEach(k => localStorage.removeItem(k));
          alert('Cleared ' + keys.length + ' feedback entries.');
        }}
      />
    </div>
  );
}

function Colophon({ parallel }) {
  return (
    <footer className="mag-colophon">
      <div className="mag-cover-rule" />
      <div className="mag-colophon-grid">
        <div>
          <h4>About this magazine</h4>
          <p>{parallel
            ? 'The Sigma Edition is the same six writers, drafting the same week, in a timeline next door. Same rigour, looser rules of physics.'
            : 'Reported by six writers on six beats. Edited the way a paper used to be: read aloud, line by line, before press.'}</p>
        </div>
        <div>
          <h4>Tell us</h4>
          <p>Every article carries a feedback block. Use it. Talk back to writers from the masthead. Your settings under <em>My Edition</em> shape next week’s draft.</p>
        </div>
        <div>
          <h4>The fine print</h4>
          <p>Issue 218 · May 8, 2026 · Set in Crimson Pro, Playfair Display, and IBM Plex Mono. Pressed in good faith.</p>
        </div>
      </div>
      <div className="mag-cover-rule" />
    </footer>
  );
}

function MagTweaks({ parallel, onToggleParallel, onOpenPrefs, onOpenMasthead, onResetFeedback }) {
  const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
    "density": "regular",
    "showAds": true,
    "showResearch": true
  }/*EDITMODE-END*/;
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  useEffect(() => {
    const r = document.documentElement;
    r.dataset.density = t.density;
    r.dataset.showAds = t.showAds ? '1' : '0';
    r.dataset.showResearch = t.showResearch ? '1' : '0';
  }, [t]);
  return (
    <TweaksPanel>
      <TweakSection label="Reading mode" />
      <TweakRadio label="Universe" value={parallel ? 'parallel' : 'real'}
        options={[{value:'real',label:'Real'},{value:'parallel',label:'Parallel Σ'}]}
        onChange={(v) => { if ((v === 'parallel') !== parallel) onToggleParallel(); }} />
      <TweakSection label="Layout" />
      <TweakRadio label="Density" value={t.density}
        options={['compact','regular','airy']}
        onChange={(v) => setTweak('density', v)} />
      <TweakToggle label="Show ads" value={t.showAds} onChange={(v) => setTweak('showAds', v)} />
      <TweakToggle label="Show reporting trail" value={t.showResearch} onChange={(v) => setTweak('showResearch', v)} />
      <TweakSection label="Quick actions" />
      <TweakButton label="Open My Edition" onClick={onOpenPrefs} />
      <TweakButton label="Open Masthead" onClick={onOpenMasthead} />
      <TweakButton label="Clear my feedback" onClick={onResetFeedback} />
    </TweaksPanel>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);